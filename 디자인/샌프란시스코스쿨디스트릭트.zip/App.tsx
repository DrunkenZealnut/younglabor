import { useState } from "react";
import { Search, MapPin, Clock, Users, Trophy, Menu, X, Calendar, Building, Eye } from "lucide-react";
import { Button } from "./components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./components/ui/card";
import designImage from 'figma:asset/a3c33b5c7a49b3cf504b5c8ae0fdb3000c5d026d.png';

export default function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigationItems = [
    { name: "Home", id: "home" },
    { name: "About", id: "about" },
    { name: "Agenda", id: "agenda" },
    { name: "Sponsors", id: "sponsors" },
    { name: "Contact", id: "contact" }
  ];

  const challenges = [
    {
      icon: Building,
      title: "Historic Landmarks",
      description: "Discover SF's most iconic historical sites",
      color: "bg-coral",
      points: 150
    },
    {
      icon: Search,
      title: "Hidden Gems",
      description: "Find secret spots only locals know about",
      color: "bg-mint",
      points: 200
    },
    {
      icon: Eye,
      title: "Art & Culture",
      description: "Explore the vibrant arts scene",
      color: "bg-blue-soft",
      points: 175
    },
    {
      icon: MapPin,
      title: "Neighborhood Quest",
      description: "Navigate through diverse districts",
      color: "bg-coral-light",
      points: 125
    }
  ];

  const features = [
    {
      icon: "🏆",
      title: "Compete & Win",
      description: "Earn points and climb the leaderboard with exciting prizes awaiting top performers."
    },
    {
      icon: "📍",
      title: "GPS Navigation",
      description: "Use our interactive map to navigate to each location with real-time guidance."
    },
    {
      icon: "👥",
      title: "Team Building",
      description: "Work together with classmates to solve challenges and complete missions."
    },
    {
      icon: "📱",
      title: "Mobile Friendly",
      description: "Access everything you need from your smartphone or tablet on the go."
    }
  ];

  const renderContent = () => {
    switch (currentPage) {
      case "about":
        return (
          <div className="min-h-screen bg-gradient-hero py-16">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h1 className="text-6xl font-black mb-6">About the Hunt</h1>
                <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                  An educational adventure that transforms learning into an exciting exploration of San Francisco
                </p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
                <div>
                  <h2 className="text-4xl font-bold mb-6 text-blue-soft">Educational Excellence</h2>
                  <p className="text-lg text-gray-600 mb-6">
                    Our scavenger hunt combines curriculum-based learning with real-world exploration, 
                    making education engaging and memorable for students of all ages.
                  </p>
                  <ul className="space-y-3">
                    <li className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-coral rounded-full"></div>
                      <span>Aligned with state educational standards</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-mint rounded-full"></div>
                      <span>Promotes critical thinking and problem-solving</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <div className="w-3 h-3 bg-blue-soft rounded-full"></div>
                      <span>Encourages teamwork and collaboration</span>
                    </li>
                  </ul>
                </div>
                <div className="relative">
                  <div className="bg-white rounded-3xl p-8 shadow-lg hover-lift">
                    <div className="text-center">
                      <div className="text-6xl mb-4">🎯</div>
                      <h3 className="text-2xl font-bold mb-4">Mission Objectives</h3>
                      <p className="text-gray-600">
                        Students work in teams to complete challenges, solve puzzles, and discover 
                        San Francisco's rich history and culture.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

      case "agenda":
        return (
          <div className="min-h-screen bg-gradient-hero py-16">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h1 className="text-6xl font-black mb-6">Event Schedule</h1>
                <p className="text-xl text-gray-600">Your complete guide to the scavenger hunt day</p>
              </div>
              
              <div className="space-y-6">
                {[
                  { time: "8:00 AM", title: "Registration & Check-in", description: "Teams gather at Portola Park for registration and receive hunt materials", color: "bg-coral" },
                  { time: "8:30 AM", title: "Opening Ceremony", description: "Welcome address and hunt rules explanation", color: "bg-mint" },
                  { time: "9:00 AM", title: "Hunt Begins!", description: "Teams disperse to start their San Francisco adventure", color: "bg-blue-soft" },
                  { time: "12:00 PM", title: "Lunch Break", description: "Mid-hunt meal and progress check-in", color: "bg-coral-light" },
                  { time: "1:00 PM", title: "Hunt Continues", description: "Second half of challenges and exploration", color: "bg-mint" },
                  { time: "4:00 PM", title: "Final Submissions", description: "All teams return and submit their findings", color: "bg-blue-soft" },
                  { time: "4:30 PM", title: "Awards Ceremony", description: "Prize distribution and celebration", color: "bg-coral" }
                ].map((event, index) => (
                  <Card key={index} className="border-0 shadow-lg hover-lift">
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-6">
                        <div className={`${event.color} text-white rounded-full p-4 min-w-0`}>
                          <Clock className="w-6 h-6" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-4 mb-2">
                            <span className="text-2xl font-bold text-blue-soft">{event.time}</span>
                            <h3 className="text-xl font-bold">{event.title}</h3>
                          </div>
                          <p className="text-gray-600">{event.description}</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );

      case "sponsors":
        return (
          <div className="min-h-screen bg-gradient-hero py-16">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h1 className="text-6xl font-black mb-6">Our Sponsors</h1>
                <p className="text-xl text-gray-600">Thanks to our amazing partners who make this event possible</p>
              </div>
              
              <div className="grid md:grid-cols-3 gap-8">
                {[
                  { name: "San Francisco Museum", level: "Gold Sponsor", color: "bg-yellow-400" },
                  { name: "Bay Area Transit", level: "Silver Sponsor", color: "bg-gray-400" },
                  { name: "Local Business Alliance", level: "Bronze Sponsor", color: "bg-orange-400" },
                  { name: "SF Public Library", level: "Community Partner", color: "bg-blue-soft" },
                  { name: "Parks & Recreation", level: "Community Partner", color: "bg-mint" },
                  { name: "Education Foundation", level: "Community Partner", color: "bg-coral" }
                ].map((sponsor, index) => (
                  <Card key={index} className="text-center hover-lift border-0 shadow-lg">
                    <CardContent className="p-8">
                      <div className={`w-20 h-20 ${sponsor.color} rounded-full mx-auto mb-4 flex items-center justify-center`}>
                        <Building className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-2">{sponsor.name}</h3>
                      <p className="text-gray-600">{sponsor.level}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        );

      case "contact":
        return (
          <div className="min-h-screen bg-gradient-hero py-16">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h1 className="text-6xl font-black mb-6">Contact Us</h1>
                <p className="text-xl text-gray-600">Get in touch with our team for questions or support</p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-12">
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-6">Event Information</h3>
                    <div className="space-y-4">
                      <div className="flex items-center space-x-3">
                        <MapPin className="w-5 h-5 text-coral" />
                        <span>Portola Park, San Francisco, CA</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Calendar className="w-5 h-5 text-mint" />
                        <span>Oct 05, 2025, 11:00 AM</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Users className="w-5 h-5 text-blue-soft" />
                        <span>Open to all SF School District students</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="border-0 shadow-lg">
                  <CardContent className="p-8">
                    <h3 className="text-2xl font-bold mb-6">Support Team</h3>
                    <div className="space-y-4">
                      <p className="text-gray-600">
                        Our dedicated team is here to help with any questions about the scavenger hunt.
                      </p>
                      <Button className="w-full bg-coral hover:bg-coral-light text-white">
                        Email Support Team
                      </Button>
                      <Button variant="outline" className="w-full border-mint text-mint hover:bg-mint hover:text-white">
                        Call Event Hotline
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        );

      default: // home
        return (
          <>
            {/* Hero Section */}
            <section className="relative min-h-screen overflow-hidden bg-gradient-hero">
              {/* Floating geometric elements */}
              <div className="absolute top-20 left-10 w-16 h-16 bg-coral/30 organic-blob floating-element"></div>
              <div className="absolute top-40 right-20 w-12 h-12 bg-mint/40 rounded-full floating-element-delayed"></div>
              <div className="absolute bottom-40 left-1/4 w-20 h-20 bg-blue-soft/20 geometric-shape floating-element-slow"></div>
              <div className="absolute top-1/3 right-1/3 w-8 h-8 bg-coral/50 rounded-full floating-element"></div>
              
              <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
                <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen">
                  <div className="space-y-8">
                    <div className="space-y-4">
                      <p className="text-coral font-handwritten text-2xl">SAN FRAN</p>
                      <h1 className="text-superhunt">SUPERHUNT</h1>
                      <h2 className="text-5xl font-black text-gray-900 leading-tight">
                        SF SCHOOL DISTRICT<br />
                        <span className="text-coral">SCAVENGER HUNT</span>
                      </h2>
                    </div>
                    
                    <div className="space-y-4">
                      <p className="text-xl text-gray-600 leading-relaxed">
                        I'm a paragraph. Click here to add your own text and edit me. 
                        Let your users get to know you.
                      </p>
                      <div className="flex items-center space-x-6 text-gray-700">
                        <div className="flex items-center space-x-2">
                          <Calendar className="w-5 h-5 text-coral" />
                          <span>Oct 05, 2025, 11:00 AM</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <MapPin className="w-5 h-5 text-mint" />
                          <span>Portola Park</span>
                        </div>
                      </div>
                    </div>
                    
                    <Button 
                      size="lg" 
                      className="bg-coral hover:bg-coral-light text-white px-8 py-4 text-lg rounded-full hover-lift"
                    >
                      Get Your Tickets
                    </Button>
                  </div>
                  
                  {/* Illustration Area */}
                  <div className="relative">
                    <img 
                      src={designImage} 
                      alt="San Francisco Scavenger Hunt Illustration" 
                      className="w-full h-auto rounded-3xl shadow-lg"
                    />
                    
                    {/* Floating elements around the image */}
                    <div className="absolute -top-4 -left-4 w-8 h-8 bg-mint rounded-full bounce-gentle"></div>
                    <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-coral/70 organic-blob floating-element"></div>
                    <div className="absolute top-1/4 -right-8 w-6 h-6 bg-blue-soft rounded-full floating-element-delayed"></div>
                  </div>
                </div>
              </div>
            </section>

            {/* Features Section */}
            <section className="py-20 bg-white">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-16">
                  <h2 className="text-5xl font-black mb-6">Why Join the Hunt?</h2>
                  <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                    An educational adventure that combines learning with fun exploration of San Francisco
                  </p>
                </div>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                  {features.map((feature, index) => (
                    <Card key={index} className="border-0 shadow-lg hover-lift text-center">
                      <CardContent className="p-6">
                        <div className="text-4xl mb-4">{feature.icon}</div>
                        <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                        <p className="text-gray-600">{feature.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </section>

            {/* Challenges Section */}
            <section className="py-20 bg-cream">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="text-center mb-16">
                  <h2 className="text-5xl font-black mb-6">Hunt Challenges</h2>
                  <p className="text-xl text-gray-600">Explore different aspects of San Francisco through exciting missions</p>
                </div>
                
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {challenges.map((challenge, index) => (
                    <Card key={index} className="border-0 shadow-lg hover-lift overflow-hidden">
                      <CardContent className="p-0">
                        <div className={`${challenge.color} p-6 text-white text-center`}>
                          <challenge.icon className="w-8 h-8 mx-auto mb-3" />
                          <h3 className="text-lg font-bold">{challenge.title}</h3>
                        </div>
                        <div className="p-6">
                          <p className="text-gray-600 mb-4">{challenge.description}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-500">Points:</span>
                            <span className="text-xl font-bold text-blue-soft">{challenge.points}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </section>

            {/* CTA Section */}
            <section className="py-20 bg-gradient-blue">
              <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <h2 className="text-5xl font-black text-white mb-6">Ready for the Adventure?</h2>
                <p className="text-xl text-white/90 mb-10">
                  Join hundreds of students in the ultimate San Francisco learning experience
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button size="lg" className="bg-white text-blue-soft hover:bg-gray-50 px-8 py-4 text-lg rounded-full">
                    Register Your Team
                  </Button>
                  <Button 
                    variant="outline" 
                    size="lg" 
                    className="border-white text-white hover:bg-white hover:text-blue-soft px-8 py-4 text-lg rounded-full"
                  >
                    Learn More
                  </Button>
                </div>
              </div>
            </section>
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-cream">
      {/* Header */}
      <header className="bg-white/95 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-coral rounded-full"></div>
              <span className="text-xl font-bold">SF SUPERHUNT</span>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-8">
              {navigationItems.map((item) => (
                <button
                  key={item.id}
                  className={`font-medium transition-colors ${
                    currentPage === item.id 
                      ? 'text-coral' 
                      : 'text-gray-700 hover:text-coral'
                  }`}
                  onClick={() => setCurrentPage(item.id)}
                >
                  {item.name}
                </button>
              ))}
            </nav>
            
            {/* Social Icons */}
            <div className="hidden md:flex items-center space-x-3">
              <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                <span className="text-white text-xs">📧</span>
              </div>
              <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                <span className="text-white text-xs">📘</span>
              </div>
              <div className="w-8 h-8 bg-gray-800 rounded-full flex items-center justify-center">
                <span className="text-white text-xs">📷</span>
              </div>
            </div>
            
            {/* Mobile menu button */}
            <button
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
          
          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden border-t border-gray-200 py-4">
              <nav className="space-y-2">
                {navigationItems.map((item) => (
                  <button
                    key={item.id}
                    className={`block w-full text-left py-2 font-medium ${
                      currentPage === item.id 
                        ? 'text-coral' 
                        : 'text-gray-700'
                    }`}
                    onClick={() => {
                      setCurrentPage(item.id);
                      setIsMenuOpen(false);
                    }}
                  >
                    {item.name}
                  </button>
                ))}
              </nav>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main>
        {renderContent()}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-coral rounded-full"></div>
                <span className="text-xl font-bold">SF SUPERHUNT</span>
              </div>
              <p className="text-gray-400">
                An educational scavenger hunt bringing San Francisco's history and culture to life for students.
              </p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Quick Links</h4>
              <div className="space-y-2">
                {navigationItems.map((item) => (
                  <button
                    key={item.id}
                    className="block text-gray-400 hover:text-white transition-colors"
                    onClick={() => setCurrentPage(item.id)}
                  >
                    {item.name}
                  </button>
                ))}
              </div>
            </div>
            <div>
              <h4 className="font-bold mb-4">Contact Info</h4>
              <div className="space-y-2 text-gray-400">
                <p>San Francisco School District</p>
                <p>Portola Park, San Francisco, CA</p>
                <p>info@sfschoolhunt.edu</p>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 SF School District Superhunt. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}